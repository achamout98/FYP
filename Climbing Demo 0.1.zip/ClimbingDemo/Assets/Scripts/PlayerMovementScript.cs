﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    [SerializeField] private float jumpRaycastDistance;
    [SerializeField] private float grabDistance;
    [SerializeField] private GameObject Child;

    private Rigidbody rb;
    private Ray ray;
    private RaycastHit hit;

    private bool mouseclicked;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        mouseclicked = false;
    }

    // Update is called once per frame
    void Update()
    {
        //player rotation
        transform.rotation = Quaternion.LookRotation(Child.transform.forward);

        //grabbing rocks
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray, out hit)) {
            String tag = hit.collider.tag;
            if(tag.Equals("Rock")) {
                Transform sphere = hit.collider.gameObject.transform;
                if(Vector3.Distance(transform.position, sphere.position) <= grabDistance) {
                    if (Input.GetMouseButtonDown(0)) {
                        mouseclicked = true;
                        Vector3 new_pos = new Vector3(sphere.position.x, sphere.position.y, sphere.position.z-1f);
                        StartCoroutine(Climb(new_pos));
                    }
                }
            }  
        }

        Jump();
    }

    private IEnumerator Climb (Vector3 new_pos) {
        while (mouseclicked) {
            if (Input.GetMouseButtonUp(0)){
                mouseclicked = false;
                yield return null;
            }

            transform.position = Vector3.Lerp(transform.position, new_pos, 1f);
            yield return null;
        }
        
        yield break;
    }

    private void FixedUpdate()
    {
        Move();
    }

    private void Move()
    {
        float hAxis = Input.GetAxisRaw("Horizontal");
        float vAxis = Input.GetAxisRaw("Vertical");

        Vector3 movement = new Vector3(hAxis, 0, vAxis) * speed * Time.fixedDeltaTime;

        Vector3 newPosition = rb.position + rb.transform.TransformDirection(movement);

        rb.MovePosition(newPosition);
    }

    private void Jump()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            if(isGrounded())
            {
                rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
            }
            
        }
    }

    private bool isGrounded()
    {
        Debug.DrawRay(transform.position, Vector3.down * jumpRaycastDistance, Color.blue);
        return Physics.Raycast(transform.position, Vector3.down * jumpRaycastDistance);
    }
}
