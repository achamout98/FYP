﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float grabDistance;
    [SerializeField] private GameObject Child;

    private Rigidbody rb;
    private Ray ray;
    private RaycastHit hit;

    private bool mouseclicked;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        mouseclicked = false;
    }

    void Update()
    {
        //Player rotation (camera and playerbody both rotate)
        transform.rotation = Quaternion.LookRotation(Child.transform.forward);
        //Grabbing rocks
        Grab();

        
    }

    private void FixedUpdate()
    {
        Move();
    }

    /************************************************************************************************************/

    private void Grab()
    {
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit))
        {
            String tag = hit.collider.tag;
            if (tag.Equals("Rock"))
            {
                Transform sphere = hit.collider.gameObject.transform;
                if (Vector3.Distance(transform.position, sphere.position) <= grabDistance)
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        mouseclicked = true;

                        float x = sphere.position.x;
                        float y = sphere.position.y;
                        float z = sphere.position.z - 2f;

                        Vector3 new_pos = new Vector3(x, y, z);
                        StartCoroutine(Climb(new_pos, 0.60f));
                    }
                }
            }
        }
    }

    private IEnumerator Climb(Vector3 new_pos, float time) {
        float eta = 0f;
        Vector3 start_pos = transform.position;
        
        while (mouseclicked) {
            if (Input.GetMouseButtonUp(0)) {
                mouseclicked = false;
                yield break;
            }
            while(eta < time) {
                transform.position = Vector3.Lerp(start_pos, new_pos, (eta / time));
                eta += Time.deltaTime;
                yield return null;
            }
            StartCoroutine(Stay(new_pos));
            yield return null;
        }
        yield return null;
    }

    private IEnumerator Stay (Vector3 new_pos) {
        while (mouseclicked) {
            transform.position = new_pos;
            if (Input.GetMouseButtonUp(0)) {
                mouseclicked = false;
                StopCoroutine("Climb");
                yield break;
            }
            yield return null;
        }
        yield break;
    }


    private void Move()
    {
        float hAxis = Input.GetAxisRaw("Horizontal");
        float vAxis = Input.GetAxisRaw("Vertical");

        Vector3 movement = new Vector3(hAxis, 0, vAxis) * speed * Time.fixedDeltaTime;

        Vector3 newPosition = rb.position + rb.transform.TransformDirection(movement);

        rb.MovePosition(newPosition);
    }



    //Jumping
    /*private void Jump()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            if(isGrounded())
            {
                rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
            }
            
        }
    }

    private bool isGrounded()
    {
        Debug.DrawRay(transform.position, Vector3.down * jumpRaycastDistance, Color.blue);
        return Physics.Raycast(transform.position, Vector3.down * jumpRaycastDistance);
    }*/
}
